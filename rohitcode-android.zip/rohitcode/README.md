# rohitcode

An offline, local-files-only music player for Android, built with Kotlin and
Jetpack Compose. This is a real Android Studio project, not a mockup — it's
meant to run on a device or emulator.

## Before you open it

- **Android Studio**: a recent stable release (Ladybug or newer). If Android
  Studio offers to upgrade the Android Gradle Plugin, Gradle, or Kotlin when
  you first open the project, it's safe to accept — the versions pinned here
  were current at time of writing, and Android's upgrade assistant handles
  the migration automatically.
- **JDK 17** (Android Studio usually bundles this already).
- A physical Android device is strongly recommended for testing playback,
  fingerprint unlock, and background behavior — emulators can be finicky
  with all three, and you'll want real audio files on the device anyway.

**Important — this was written without a live Android build environment.**
I don't have network or SDK access in the sandbox I built this in, so I
couldn't run `./gradlew build` or open it in Android Studio myself before
handing it to you. The code follows the current, documented Media3/Compose/
Room APIs as carefully as I could, but treat the first build like you would
any new checkout: expect Android Studio to flag a handful of small things
(an import, a deprecated call, a version nudge) rather than a guaranteed
one-shot compile. None of that should be structural — if something doesn't
resolve, it's very likely a one-line fix, and I'm glad to help debug once
you see the actual error.

## Getting it running

1. Open the `rohitcode` folder in Android Studio ("Open" → select the
   folder, not a file inside it).
2. Let Gradle sync. First sync can take a few minutes.
3. Connect an Android device (USB debugging on) or start an emulator running
   API 26+.
4. Run the `app` configuration.
5. On first launch, grant the audio permission prompt — without it the
   library will just look empty.

## How the pieces fit together

```
data/            Song model, MediaStore scanning (MusicRepository),
                 Room playlist storage (data/db) and PlaylistRepository
settings/        DataStore-backed preferences (theme, lock, repeat, background)
security/        Password hashing + verification, BiometricPrompt wrapper
playback/        PlaybackService (Media3 MediaSessionService) + PlayerViewModel
viewmodel/       LibraryViewModel, SettingsViewModel, and the factory that wires
                 everything together (see AppContainer in RohitCodeApplication.kt)
ui/theme/        Color, shape (50dp rounding), and Material3 theme
ui/components/   Shared pieces: song rows, playlist cards, mini player, switches
ui/screens/      LockScreen, LibraryScreen, NowPlayingScreen, SettingsScreen
MainActivity.kt  Permission request, lock gate, navigation between screens
```

There's no Hilt or Dagger here — dependencies are wired by hand in
`AppContainer`. For a project this size that's easier to read and step
through than generated DI code, and it's a reasonable thing to swap in later
if the app grows.

## Where each feature from your brief lives

| Feature | Where |
|---|---|
| Basic player controls | `NowPlayingScreen.kt`, backed by ExoPlayer in `PlaybackService.kt` |
| Custom repeat count per song | `PlayerViewModel.kt` — tracks loops itself via `onPositionDiscontinuity` since ExoPlayer only natively supports off/one/all |
| Create playlists | `LibraryScreen.kt` (the `+` button) → `PlaylistRepository` → Room |
| Remove from played queue without touching the saved playlist | `PlayerViewModel.playQueue()` copies the playlist into an in-memory queue; `removeFromQueue()` only edits that copy |
| Background playback | `PlaybackService.kt`, a Media3 `MediaSessionService` (foreground service + notification, handled by the framework) |
| Sleep timer | `PlayerViewModel.startSleepTimer()` / `cancelSleepTimer()`, triggered from the clock chip on Now Playing |
| Password + fingerprint lock | `AppLockManager.kt` (hashed password) + `BiometricAuthHelper.kt` (fingerprint), gated in `MainActivity.kt`, toggled in `SettingsScreen.kt` |
| Dark/light theme toggle | `ui/theme/Theme.kt` + the switch in `SettingsScreen.kt`, persisted via `SettingsRepository` |

## Deliberate simplifications in this first version

To keep the first build focused and easy to reason about, a few things were
left as clear next steps rather than built out now:

- **Album art** isn't wired up yet — songs show a gradient placeholder
  instead of real artwork. Adding it means reading each song's album art
  (via `MediaStore` or a library like Coil) and swapping it into `SongRow`,
  `PlaylistCard`, and the Now Playing art box.
- **Search and a dedicated Playlists tab** aren't separate screens yet —
  everything lives on one Library screen, matching the four screens we
  designed together. Both are natural additions once the core app feels
  right.
- **Favorites** toggle visually on Now Playing but aren't saved anywhere
  yet — persisting them would mean one more small Room table.
- **Shuffle** calls ExoPlayer's real shuffle mode but the queue list shown
  on screen doesn't yet reorder to match — cosmetic only, playback order is
  correct.

None of these affect the eight features from your original brief — they're
just the layer beyond that we didn't build yet.

## If something doesn't build

The most likely first hiccups, and what they usually mean:
- **"Unresolved reference" on a Compose or Media3 API** — a library version
  moved a class or function. Check the error against that library's release
  notes, or just tell me the exact error and I'll patch it.
- **KSP/Room annotation errors** — usually a Kotlin/KSP version mismatch;
  Android Studio's Gradle upgrade prompt normally fixes this in one click.
- **Biometric prompt doesn't appear on an emulator** — enroll a fingerprint
  in the emulator's extended controls first, or test on a physical device.
