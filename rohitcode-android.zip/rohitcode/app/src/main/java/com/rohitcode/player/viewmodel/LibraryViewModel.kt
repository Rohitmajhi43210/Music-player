package com.rohitcode.player.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.rohitcode.player.data.MusicRepository
import com.rohitcode.player.data.PlaylistRepository
import com.rohitcode.player.data.Song
import com.rohitcode.player.data.db.PlaylistEntity
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch

class LibraryViewModel(
    private val musicRepository: MusicRepository,
    private val playlistRepository: PlaylistRepository
) : ViewModel() {

    private val _songs = MutableStateFlow<List<Song>>(emptyList())
    val songs: StateFlow<List<Song>> = _songs.asStateFlow()

    private val _playlists = MutableStateFlow<List<PlaylistEntity>>(emptyList())
    val playlists: StateFlow<List<PlaylistEntity>> = _playlists.asStateFlow()

    init {
        viewModelScope.launch {
            playlistRepository.observePlaylists().collect { _playlists.value = it }
        }
    }

    /** Call after the storage permission has been granted (or on every resume — it's cheap). */
    fun loadSongs() {
        viewModelScope.launch {
            _songs.value = musicRepository.loadAllSongs()
        }
    }

    fun createPlaylist(name: String) {
        viewModelScope.launch { playlistRepository.createPlaylist(name) }
    }

    fun addSongToPlaylist(playlistId: Long, songId: Long) {
        viewModelScope.launch { playlistRepository.addSong(playlistId, songId) }
    }

    suspend fun songsForPlaylist(playlistId: Long): List<Song> = playlistRepository.songsFor(playlistId)
}
