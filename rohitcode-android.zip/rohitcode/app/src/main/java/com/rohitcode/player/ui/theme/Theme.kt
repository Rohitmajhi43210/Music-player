package com.rohitcode.player.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

private val DarkColors = darkColorScheme(
    background = NavyDeep,
    surface = NavyDeep,
    surfaceVariant = Color.White.copy(alpha = 0.07f),
    onBackground = Color.White,
    onSurface = Color.White,
    primary = Sky,
    onPrimary = NavyDeepest,
    secondary = Sky,
    error = Color(0xFFFF8A80),
    outline = Color.White.copy(alpha = 0.12f)
)

private val LightColors = lightColorScheme(
    background = OffWhite,
    surface = OffWhite,
    surfaceVariant = NavyDeep.copy(alpha = 0.05f),
    onBackground = NavyDeep,
    onSurface = NavyDeep,
    primary = Slate,
    onPrimary = Color.White,
    secondary = Slate,
    error = Color(0xFFB3261E),
    outline = NavyDeep.copy(alpha = 0.08f)
)

@Composable
fun RohitCodeTheme(darkTheme: Boolean, content: @Composable () -> Unit) {
    val colors = if (darkTheme) DarkColors else LightColors
    MaterialTheme(colorScheme = colors, shapes = RohitShapes, content = content)
}
