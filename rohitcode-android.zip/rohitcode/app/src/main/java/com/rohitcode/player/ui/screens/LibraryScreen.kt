package com.rohitcode.player.ui.screens

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.rohitcode.player.data.Song
import com.rohitcode.player.playback.PlayerViewModel
import com.rohitcode.player.ui.components.AddToPlaylistSheet
import com.rohitcode.player.ui.components.CreatePlaylistDialog
import com.rohitcode.player.ui.components.MiniPlayerBar
import com.rohitcode.player.ui.components.PlaylistCard
import com.rohitcode.player.ui.components.RohitBottomBar
import com.rohitcode.player.ui.components.SongRow
import com.rohitcode.player.viewmodel.LibraryViewModel
import kotlinx.coroutines.launch

@Composable
fun LibraryScreen(
    libraryViewModel: LibraryViewModel,
    playerViewModel: PlayerViewModel,
    onOpenNowPlaying: () -> Unit,
    onOpenSettings: () -> Unit
) {
    val songs by libraryViewModel.songs.collectAsState()
    val playlists by libraryViewModel.playlists.collectAsState()
    val playerState by playerViewModel.uiState.collectAsState()
    val scope = rememberCoroutineScope()

    var showCreateDialog by remember { mutableStateOf(false) }
    var addToPlaylistSong by remember { mutableStateOf<Song?>(null) }

    LaunchedEffect(Unit) { libraryViewModel.loadSongs() }

    val nowPlayingSong = playerState.queue.getOrNull(playerState.currentIndex)

    Scaffold(
        bottomBar = {
            Column {
                if (nowPlayingSong != null) {
                    MiniPlayerBar(
                        song = nowPlayingSong,
                        isPlaying = playerState.isPlaying,
                        onTogglePlay = { playerViewModel.togglePlayPause() },
                        onClick = onOpenNowPlaying,
                        modifier = Modifier.padding(horizontal = 16.dp, vertical = 8.dp)
                    )
                }
                RohitBottomBar(selected = "home", onHome = {}, onSettings = onOpenSettings)
            }
        }
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .padding(horizontal = 20.dp)
        ) {
            Spacer(Modifier.height(12.dp))
            Text("Good evening", style = MaterialTheme.typography.titleLarge)
            Text(
                "Local files, ready to play",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.6f)
            )

            Spacer(Modifier.height(20.dp))
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text("Your playlists", style = MaterialTheme.typography.labelLarge)
                IconButton(onClick = { showCreateDialog = true }) {
                    Icon(Icons.Filled.Add, contentDescription = "Create playlist")
                }
            }
            LazyRow(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                items(playlists, key = { it.id }) { playlist ->
                    PlaylistCard(
                        playlist = playlist,
                        onClick = {
                            scope.launch {
                                val playlistSongs = libraryViewModel.songsForPlaylist(playlist.id)
                                if (playlistSongs.isNotEmpty()) {
                                    playerViewModel.playQueue(playlistSongs, sourcePlaylistName = playlist.name)
                                    onOpenNowPlaying()
                                }
                            }
                        }
                    )
                }
            }

            Spacer(Modifier.height(20.dp))
            Text("All songs", style = MaterialTheme.typography.labelLarge)
            Spacer(Modifier.height(8.dp))

            if (songs.isEmpty()) {
                Text(
                    "No local audio found yet. Add some music to your device, or check the storage permission was granted.",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.6f),
                    modifier = Modifier.padding(top = 12.dp)
                )
            }

            LazyColumn(
                modifier = Modifier.weight(1f),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                items(songs, key = { it.id }) { song ->
                    SongRow(
                        song = song,
                        onClick = {
                            val index = songs.indexOf(song)
                            playerViewModel.playQueue(songs, startIndex = index, sourcePlaylistName = null)
                            onOpenNowPlaying()
                        },
                        onMoreClick = { addToPlaylistSong = song }
                    )
                }
                item { Spacer(Modifier.height(24.dp)) }
            }
        }
    }

    if (showCreateDialog) {
        CreatePlaylistDialog(
            onDismiss = { showCreateDialog = false },
            onCreate = { name ->
                libraryViewModel.createPlaylist(name)
                showCreateDialog = false
            }
        )
    }

    addToPlaylistSong?.let { song ->
        AddToPlaylistSheet(
            playlists = playlists,
            onDismiss = { addToPlaylistSong = null },
            onPlaylistPicked = { playlistId ->
                libraryViewModel.addSongToPlaylist(playlistId, song.id)
                addToPlaylistSong = null
            }
        )
    }
}
