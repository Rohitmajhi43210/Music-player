package com.rohitcode.player

import android.Manifest
import android.os.Build
import android.os.Bundle
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.Surface
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.fragment.app.FragmentActivity
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import com.rohitcode.player.playback.PlayerViewModel
import com.rohitcode.player.security.BiometricAuthHelper
import com.rohitcode.player.ui.screens.LibraryScreen
import com.rohitcode.player.ui.screens.LockScreen
import com.rohitcode.player.ui.screens.NowPlayingScreen
import com.rohitcode.player.ui.screens.SettingsScreen
import com.rohitcode.player.ui.theme.RohitCodeTheme
import com.rohitcode.player.viewmodel.LibraryViewModel
import com.rohitcode.player.viewmodel.RohitViewModelFactory
import com.rohitcode.player.viewmodel.SettingsViewModel

private object Routes {
    const val LIBRARY = "library"
    const val NOW_PLAYING = "now_playing"
    const val SETTINGS = "settings"
}

class MainActivity : FragmentActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val container = (application as RohitCodeApplication).container
        val factory = RohitViewModelFactory(this, container)
        val biometricHelper = BiometricAuthHelper(this)

        val permissionLauncher = registerForActivityResult(ActivityResultContracts.RequestPermission()) { }

        setContent {
            val settingsViewModel: SettingsViewModel = viewModel(factory = factory)
            val libraryViewModel: LibraryViewModel = viewModel(factory = factory)
            val playerViewModel: PlayerViewModel = viewModel(factory = factory)

            val isDark by settingsViewModel.settingsRepository.isDarkTheme.collectAsState(initial = true)
            val passwordEnabled by settingsViewModel.settingsRepository.isPasswordEnabled.collectAsState(initial = false)
            val fingerprintEnabled by settingsViewModel.settingsRepository.isFingerprintEnabled.collectAsState(initial = true)

            var unlocked by rememberSaveable { mutableStateOf(false) }
            val lockRequired = passwordEnabled || fingerprintEnabled
            val biometricAvailable = remember { biometricHelper.isAvailable() }

            LaunchedEffect(Unit) {
                val permission = if (Build.VERSION.SDK_INT >= 33) {
                    Manifest.permission.READ_MEDIA_AUDIO
                } else {
                    Manifest.permission.READ_EXTERNAL_STORAGE
                }
                permissionLauncher.launch(permission)
            }

            RohitCodeTheme(darkTheme = isDark) {
                Surface(modifier = Modifier.fillMaxSize()) {
                    if (lockRequired && !unlocked) {
                        LockScreen(
                            fingerprintEnabled = fingerprintEnabled,
                            passwordEnabled = passwordEnabled,
                            biometricAvailable = biometricAvailable,
                            onBiometricRequested = {
                                biometricHelper.authenticate(
                                    onSuccess = { unlocked = true },
                                    onError = { /* user can fall back to password, or try again */ }
                                )
                            },
                            onPasswordEntered = { pin -> settingsViewModel.appLockManager.verifyPassword(pin) },
                            onUnlocked = { unlocked = true }
                        )
                    } else {
                        val navController = rememberNavController()
                        NavHost(navController = navController, startDestination = Routes.LIBRARY) {
                            composable(Routes.LIBRARY) {
                                LibraryScreen(
                                    libraryViewModel = libraryViewModel,
                                    playerViewModel = playerViewModel,
                                    onOpenNowPlaying = { navController.navigate(Routes.NOW_PLAYING) },
                                    onOpenSettings = { navController.navigate(Routes.SETTINGS) }
                                )
                            }
                            composable(Routes.NOW_PLAYING) {
                                NowPlayingScreen(
                                    playerViewModel = playerViewModel,
                                    onBack = { navController.popBackStack() }
                                )
                            }
                            composable(Routes.SETTINGS) {
                                SettingsScreen(
                                    settingsViewModel = settingsViewModel,
                                    biometricAvailable = biometricAvailable,
                                    onOpenLibrary = {
                                        navController.navigate(Routes.LIBRARY) {
                                            popUpTo(Routes.LIBRARY) { inclusive = true }
                                        }
                                    }
                                )
                            }
                        }
                    }
                }
            }
        }
    }
}
