package com.rohitcode.player.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Fingerprint
import androidx.compose.material.icons.filled.MusicNote
import androidx.compose.material3.Button
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import com.rohitcode.player.ui.theme.NavyDeepest

@Composable
fun LockScreen(
    fingerprintEnabled: Boolean,
    passwordEnabled: Boolean,
    biometricAvailable: Boolean,
    onBiometricRequested: () -> Unit,
    onPasswordEntered: (String) -> Boolean,
    onUnlocked: () -> Unit
) {
    val canUseFingerprint = fingerprintEnabled && biometricAvailable
    var showPasswordField by remember { mutableStateOf(!canUseFingerprint) }
    var pin by remember { mutableStateOf("") }
    var error by remember { mutableStateOf(false) }

    LaunchedEffect(Unit) {
        if (canUseFingerprint) onBiometricRequested()
    }

    Column(
        modifier = Modifier.fillMaxSize().padding(32.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        Box(
            modifier = Modifier.size(72.dp).clip(CircleShape).background(NavyDeepest),
            contentAlignment = Alignment.Center
        ) {
            Icon(Icons.Filled.MusicNote, contentDescription = null, tint = MaterialTheme.colorScheme.primary)
        }

        Spacer(Modifier.height(24.dp))
        Text("Welcome back", style = MaterialTheme.typography.titleLarge)
        Spacer(Modifier.height(4.dp))
        Text(
            "Unlock rohitcode to get back to your library.",
            style = MaterialTheme.typography.bodyMedium,
            color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.7f),
            textAlign = TextAlign.Center
        )
        Spacer(Modifier.height(32.dp))

        when {
            !showPasswordField && canUseFingerprint -> {
                OutlinedButton(onClick = onBiometricRequested, shape = CircleShape, modifier = Modifier.size(88.dp)) {
                    Icon(Icons.Filled.Fingerprint, contentDescription = "Unlock with fingerprint", modifier = Modifier.size(34.dp))
                }
                Spacer(Modifier.height(12.dp))
                Text("Touch to unlock", style = MaterialTheme.typography.bodySmall)
                if (passwordEnabled) {
                    Spacer(Modifier.height(24.dp))
                    TextButton(onClick = { showPasswordField = true }) { Text("Use password instead") }
                }
            }

            passwordEnabled -> {
                OutlinedTextField(
                    value = pin,
                    onValueChange = { pin = it; error = false },
                    label = { Text("Password") },
                    singleLine = true,
                    isError = error,
                    visualTransformation = PasswordVisualTransformation()
                )
                if (error) {
                    Spacer(Modifier.height(4.dp))
                    Text(
                        "That password's not right. Try again.",
                        color = MaterialTheme.colorScheme.error,
                        style = MaterialTheme.typography.bodySmall
                    )
                }
                Spacer(Modifier.height(16.dp))
                Button(onClick = { if (onPasswordEntered(pin)) onUnlocked() else error = true }) {
                    Text("Unlock")
                }
                if (canUseFingerprint) {
                    Spacer(Modifier.height(16.dp))
                    TextButton(onClick = { showPasswordField = false }) { Text("Use fingerprint instead") }
                }
            }

            else -> {
                Text(
                    "No unlock method is set up. Turn on password protection or fingerprint unlock in Settings.",
                    textAlign = TextAlign.Center,
                    style = MaterialTheme.typography.bodyMedium
                )
            }
        }
    }
}
