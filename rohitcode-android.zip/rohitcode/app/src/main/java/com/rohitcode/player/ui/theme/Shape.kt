package com.rohitcode.player.ui.theme

import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Shapes
import androidx.compose.ui.unit.dp

val RohitShapes = Shapes(
    extraSmall = RoundedCornerShape(16.dp),
    small = RoundedCornerShape(24.dp),
    medium = RoundedCornerShape(32.dp),
    large = RoundedCornerShape(50.dp),
    extraLarge = RoundedCornerShape(50.dp)
)

/** The brief's signature rounding, used directly on pills, chips and bars. */
val PillShape = RoundedCornerShape(50.dp)
val CardShape = RoundedCornerShape(24.dp)
val ArtShape = RoundedCornerShape(50.dp)
