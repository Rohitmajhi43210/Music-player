package com.rohitcode.player.security

import android.content.Context
import androidx.security.crypto.EncryptedSharedPreferences
import androidx.security.crypto.MasterKey
import java.security.MessageDigest

/**
 * Stores a hashed password on-device using AndroidX Security's encrypted
 * SharedPreferences. Only the hash is ever persisted — never the raw
 * password the user typed.
 */
class AppLockManager(context: Context) {

    private val masterKey = MasterKey.Builder(context)
        .setKeyScheme(MasterKey.KeyScheme.AES256_GCM)
        .build()

    private val prefs = EncryptedSharedPreferences.create(
        context,
        "rohitcode_secure_prefs",
        masterKey,
        EncryptedSharedPreferences.PrefKeyEncryptionScheme.AES256_SIV,
        EncryptedSharedPreferences.PrefValueEncryptionScheme.AES256_GCM
    )

    fun hasPassword(): Boolean = prefs.contains(KEY_PASSWORD_HASH)

    fun setPassword(rawPassword: String) {
        prefs.edit().putString(KEY_PASSWORD_HASH, hash(rawPassword)).apply()
    }

    fun clearPassword() {
        prefs.edit().remove(KEY_PASSWORD_HASH).apply()
    }

    fun verifyPassword(rawPassword: String): Boolean {
        val stored = prefs.getString(KEY_PASSWORD_HASH, null) ?: return false
        return stored == hash(rawPassword)
    }

    private fun hash(value: String): String {
        val digest = MessageDigest.getInstance("SHA-256").digest(value.toByteArray())
        return digest.joinToString("") { "%02x".format(it) }
    }

    companion object {
        private const val KEY_PASSWORD_HASH = "password_hash"
    }
}
