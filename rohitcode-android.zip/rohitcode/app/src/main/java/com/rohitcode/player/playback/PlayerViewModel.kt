package com.rohitcode.player.playback

import android.content.ComponentName
import android.content.Context
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import androidx.media3.common.MediaItem
import androidx.media3.common.Player
import androidx.media3.session.MediaController
import androidx.media3.session.SessionToken
import com.google.common.util.concurrent.MoreExecutors
import com.rohitcode.player.data.Song
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch

/** A repeat target this large is, for practical purposes, "repeat forever". */
const val REPEAT_INFINITE = 99

data class PlayerUiState(
    val queue: List<Song> = emptyList(),
    val currentIndex: Int = -1,
    val isPlaying: Boolean = false,
    val positionMs: Long = 0L,
    val durationMs: Long = 0L,
    val repeatTarget: Int = 1,
    val repeatsCompleted: Int = 0,
    val isFavorite: Boolean = false,
    val sourcePlaylistName: String? = null,
    val sleepTimerMinutesRemaining: Int? = null
)

/**
 * Wraps a [MediaController] connected to [PlaybackService]. Talking to the
 * player through a controller (rather than holding the service directly)
 * is the pattern Media3 expects, and it's what lets playback keep going
 * correctly whether the UI is in the foreground or not.
 */
class PlayerViewModel(context: Context) : ViewModel() {

    private val appContext = context.applicationContext
    private var controller: MediaController? = null
    private var sleepTimerJob: Job? = null

    private val _uiState = MutableStateFlow(PlayerUiState())
    val uiState: StateFlow<PlayerUiState> = _uiState.asStateFlow()

    init {
        val sessionToken = SessionToken(appContext, ComponentName(appContext, PlaybackService::class.java))
        val controllerFuture = MediaController.Builder(appContext, sessionToken).buildAsync()
        controllerFuture.addListener(
            {
                controller = controllerFuture.get()
                controller?.repeatMode = Player.REPEAT_MODE_ONE
                attachListener()
            },
            MoreExecutors.directExecutor()
        )
    }

    private fun attachListener() {
        controller?.addListener(object : Player.Listener {

            override fun onIsPlayingChanged(isPlaying: Boolean) {
                _uiState.value = _uiState.value.copy(isPlaying = isPlaying)
            }

            override fun onMediaItemTransition(mediaItem: MediaItem?, reason: Int) {
                val index = controller?.currentMediaItemIndex ?: -1
                _uiState.value = _uiState.value.copy(currentIndex = index, repeatsCompleted = 0)
            }

            override fun onPositionDiscontinuity(
                oldPosition: Player.PositionInfo,
                newPosition: Player.PositionInfo,
                reason: Int
            ) {
                // Because repeatMode is always REPEAT_MODE_ONE, an "auto transition"
                // that lands back on the same item means the track just looped.
                // We count these loops ourselves to support a custom repeat count,
                // then advance manually once the target is reached.
                if (reason == Player.DISCONTINUITY_REASON_AUTO_TRANSITION &&
                    oldPosition.mediaItemIndex == newPosition.mediaItemIndex
                ) {
                    val c = controller ?: return
                    val state = _uiState.value
                    val completed = state.repeatsCompleted + 1
                    if (completed >= state.repeatTarget) {
                        _uiState.value = state.copy(repeatsCompleted = 0)
                        c.seekToNextMediaItem()
                    } else {
                        _uiState.value = state.copy(repeatsCompleted = completed)
                    }
                }
            }
        })
    }

    /** Loads a queue and starts playing it. This is a *copy* of whatever list was passed in. */
    fun playQueue(
        songs: List<Song>,
        startIndex: Int = 0,
        sourcePlaylistName: String? = null,
        repeatTarget: Int = _uiState.value.repeatTarget
    ) {
        val c = controller ?: return
        val items = songs.map { song ->
            MediaItem.Builder()
                .setUri(song.contentUri)
                .setMediaId(song.id.toString())
                .build()
        }
        c.setMediaItems(items, startIndex.coerceIn(0, items.lastIndex.coerceAtLeast(0)), 0L)
        c.repeatMode = Player.REPEAT_MODE_ONE
        c.prepare()
        c.play()
        _uiState.value = _uiState.value.copy(
            queue = songs,
            currentIndex = startIndex,
            sourcePlaylistName = sourcePlaylistName,
            repeatTarget = repeatTarget,
            repeatsCompleted = 0,
            isFavorite = false
        )
    }

    fun togglePlayPause() {
        val c = controller ?: return
        if (c.isPlaying) c.pause() else c.play()
    }

    fun skipNext() = controller?.seekToNextMediaItem()
    fun skipPrevious() = controller?.seekToPreviousMediaItem()

    fun toggleShuffle() {
        val c = controller ?: return
        c.shuffleModeEnabled = !c.shuffleModeEnabled
    }

    fun toggleFavorite() {
        _uiState.value = _uiState.value.copy(isFavorite = !_uiState.value.isFavorite)
    }

    fun setRepeatTarget(count: Int) {
        _uiState.value = _uiState.value.copy(repeatTarget = count, repeatsCompleted = 0)
    }

    /** Cycles the badge through x1 -> x2 -> x3 -> infinite -> x1. */
    fun cycleRepeatTarget() {
        val next = when (_uiState.value.repeatTarget) {
            1 -> 2
            2 -> 3
            3 -> REPEAT_INFINITE
            else -> 1
        }
        setRepeatTarget(next)
    }

    /**
     * Removes a song from the *live queue* only. The saved playlist this
     * queue was loaded from (in Room) is never touched here.
     */
    fun removeFromQueue(index: Int) {
        val c = controller ?: return
        val queue = _uiState.value.queue
        if (index < 0 || index >= queue.size) return
        c.removeMediaItem(index)
        val newQueue = queue.toMutableList().also { it.removeAt(index) }
        _uiState.value = _uiState.value.copy(queue = newQueue, currentIndex = c.currentMediaItemIndex)
    }

    fun removeCurrentFromQueue() = removeFromQueue(_uiState.value.currentIndex)

    fun startSleepTimer(minutes: Int) {
        sleepTimerJob?.cancel()
        _uiState.value = _uiState.value.copy(sleepTimerMinutesRemaining = minutes)
        sleepTimerJob = viewModelScope.launch {
            var remaining = minutes
            while (remaining > 0) {
                delay(60_000)
                remaining -= 1
                _uiState.value = _uiState.value.copy(sleepTimerMinutesRemaining = remaining)
            }
            controller?.pause()
            _uiState.value = _uiState.value.copy(sleepTimerMinutesRemaining = null)
        }
    }

    fun cancelSleepTimer() {
        sleepTimerJob?.cancel()
        _uiState.value = _uiState.value.copy(sleepTimerMinutesRemaining = null)
    }

    /** Call periodically from the UI (e.g. every 500ms while Now Playing is visible). */
    fun refreshPosition() {
        val c = controller ?: return
        _uiState.value = _uiState.value.copy(
            positionMs = c.currentPosition.coerceAtLeast(0),
            durationMs = c.duration.coerceAtLeast(0)
        )
    }

    override fun onCleared() {
        controller?.release()
        controller = null
        super.onCleared()
    }
}
