package com.rohitcode.player.data

import com.rohitcode.player.data.db.PlaylistDao
import com.rohitcode.player.data.db.PlaylistEntity
import com.rohitcode.player.data.db.PlaylistSongEntity
import kotlinx.coroutines.flow.Flow

class PlaylistRepository(
    private val dao: PlaylistDao,
    private val musicRepository: MusicRepository
) {
    fun observePlaylists(): Flow<List<PlaylistEntity>> = dao.observePlaylists()

    suspend fun createPlaylist(name: String): Long = dao.insertPlaylist(PlaylistEntity(name = name))

    suspend fun deletePlaylist(playlistId: Long) = dao.deletePlaylist(playlistId)

    suspend fun addSong(playlistId: Long, songId: Long) {
        val position = dao.nextPosition(playlistId)
        dao.addSongToPlaylist(PlaylistSongEntity(playlistId, songId, position))
    }

    suspend fun removeSong(playlistId: Long, songId: Long) = dao.removeSongFromPlaylist(playlistId, songId)

    /**
     * Resolves a playlist's saved song IDs against the current on-device
     * library. This is the *saved* playlist — separate from whatever is
     * currently in the player's live queue.
     */
    suspend fun songsFor(playlistId: Long): List<Song> {
        val allSongs = musicRepository.loadAllSongs().associateBy { it.id }
        val ids = dao.getSongIdsForPlaylist(playlistId)
        return ids.mapNotNull { allSongs[it] }
    }

    suspend fun songCount(playlistId: Long): Int = dao.songCount(playlistId)
}
