package com.rohitcode.player.ui.screens

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.DarkMode
import androidx.compose.material.icons.filled.Fingerprint
import androidx.compose.material.icons.filled.Headset
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.Remove
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import com.rohitcode.player.ui.components.RohitBottomBar
import com.rohitcode.player.ui.components.SwitchRow
import com.rohitcode.player.viewmodel.SettingsViewModel

@Composable
fun SettingsScreen(
    settingsViewModel: SettingsViewModel,
    biometricAvailable: Boolean,
    onOpenLibrary: () -> Unit
) {
    val isDark by settingsViewModel.settingsRepository.isDarkTheme.collectAsState(initial = true)
    val passwordEnabled by settingsViewModel.settingsRepository.isPasswordEnabled.collectAsState(initial = false)
    val fingerprintEnabled by settingsViewModel.settingsRepository.isFingerprintEnabled.collectAsState(initial = true)
    val defaultRepeatCount by settingsViewModel.settingsRepository.defaultRepeatCount.collectAsState(initial = 1)
    val backgroundPlayback by settingsViewModel.settingsRepository.backgroundPlaybackEnabled.collectAsState(initial = true)

    var showSetPasswordDialog by remember { mutableStateOf(false) }

    Scaffold(
        bottomBar = { RohitBottomBar(selected = "settings", onHome = onOpenLibrary, onSettings = {}) }
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .padding(horizontal = 20.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            Spacer(Modifier.height(8.dp))
            Text("Settings", style = MaterialTheme.typography.headlineSmall)

            SectionLabel("Appearance")
            SwitchRow(Icons.Filled.DarkMode, "Dark theme", isDark) { settingsViewModel.setDarkTheme(it) }

            SectionLabel("Security")
            SwitchRow(Icons.Filled.Lock, "Password protection", passwordEnabled) { enabled ->
                if (enabled) showSetPasswordDialog = true else settingsViewModel.disablePassword()
            }
            SwitchRow(
                Icons.Filled.Fingerprint,
                "Fingerprint unlock",
                fingerprintEnabled && biometricAvailable
            ) { settingsViewModel.setFingerprintEnabled(it) }
            if (!biometricAvailable) {
                Text(
                    "This device doesn't have fingerprint hardware set up, so this stays off.",
                    style = MaterialTheme.typography.labelSmall,
                    color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.6f)
                )
            }

            SectionLabel("Playback")
            RepeatCountRow(defaultRepeatCount) { settingsViewModel.setDefaultRepeatCount(it) }
            SwitchRow(Icons.Filled.Headset, "Play in background", backgroundPlayback) {
                settingsViewModel.setBackgroundPlayback(it)
            }
        }
    }

    if (showSetPasswordDialog) {
        SetPasswordDialog(
            onDismiss = { showSetPasswordDialog = false },
            onConfirm = { pin ->
                settingsViewModel.setPassword(pin)
                showSetPasswordDialog = false
            }
        )
    }
}

@Composable
private fun SectionLabel(text: String) {
    Text(text, style = MaterialTheme.typography.labelMedium, modifier = Modifier.padding(top = 8.dp))
}

@Composable
private fun RepeatCountRow(value: Int, onChange: (Int) -> Unit) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text("Default repeat count", style = MaterialTheme.typography.bodyMedium)
        Row(verticalAlignment = Alignment.CenterVertically) {
            IconButton(onClick = { if (value > 1) onChange(value - 1) }) {
                Icon(Icons.Filled.Remove, contentDescription = "Decrease")
            }
            Text("\u00d7$value")
            IconButton(onClick = { onChange(value + 1) }) {
                Icon(Icons.Filled.Add, contentDescription = "Increase")
            }
        }
    }
}

@Composable
private fun SetPasswordDialog(onDismiss: () -> Unit, onConfirm: (String) -> Unit) {
    var pin by remember { mutableStateOf("") }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Set a password") },
        text = {
            OutlinedTextField(
                value = pin,
                onValueChange = { pin = it },
                label = { Text("New password") },
                singleLine = true,
                visualTransformation = PasswordVisualTransformation()
            )
        },
        confirmButton = {
            TextButton(onClick = { if (pin.isNotBlank()) onConfirm(pin) }) { Text("Save") }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) { Text("Cancel") }
        }
    )
}
