package com.rohitcode.player.ui.theme

import androidx.compose.ui.graphics.Color

val NavyDeepest = Color(0xFF0B1B32)
val NavyDeep = Color(0xFF0D1E4C)
val Slate = Color(0xFF26415E)
val Sky = Color(0xFF83A6CE)
val OffWhite = Color(0xFFFBFCFE)
