package com.rohitcode.player.data

import android.net.Uri

/**
 * A single track, resolved from the device's MediaStore. Songs are never
 * duplicated into our own database — playlists just remember which song
 * IDs belong to them (see [com.rohitcode.player.data.db.PlaylistSongEntity]).
 */
data class Song(
    val id: Long,
    val title: String,
    val artist: String,
    val album: String,
    val durationMs: Long,
    val contentUri: Uri
)
