package com.rohitcode.player

import android.app.Application
import com.rohitcode.player.data.MusicRepository
import com.rohitcode.player.data.PlaylistRepository
import com.rohitcode.player.data.db.AppDatabase
import com.rohitcode.player.security.AppLockManager
import com.rohitcode.player.settings.SettingsRepository

class RohitCodeApplication : Application() {

    lateinit var container: AppContainer
        private set

    override fun onCreate() {
        super.onCreate()
        container = AppContainer(this)
    }
}

/**
 * A small, hand-written dependency container. There's no Hilt/Dagger here
 * on purpose — for a project this size, plain constructors are easier to
 * read and step through than a DI framework's generated code.
 */
class AppContainer(app: Application) {
    val musicRepository = MusicRepository(app)
    val database = AppDatabase.getInstance(app)
    val playlistRepository = PlaylistRepository(database.playlistDao(), musicRepository)
    val settingsRepository = SettingsRepository(app)
    val appLockManager = AppLockManager(app)
}
