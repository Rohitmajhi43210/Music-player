package com.rohitcode.player.settings

import android.content.Context
import androidx.datastore.preferences.core.booleanPreferencesKey
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.intPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map

private val Context.dataStore by preferencesDataStore(name = "rohitcode_settings")

class SettingsRepository(private val context: Context) {

    private object Keys {
        val DARK_THEME = booleanPreferencesKey("dark_theme")
        val PASSWORD_ENABLED = booleanPreferencesKey("password_enabled")
        val FINGERPRINT_ENABLED = booleanPreferencesKey("fingerprint_enabled")
        val DEFAULT_REPEAT_COUNT = intPreferencesKey("default_repeat_count")
        val BACKGROUND_PLAYBACK = booleanPreferencesKey("background_playback")
    }

    val isDarkTheme: Flow<Boolean> = context.dataStore.data.map { it[Keys.DARK_THEME] ?: true }
    val isPasswordEnabled: Flow<Boolean> = context.dataStore.data.map { it[Keys.PASSWORD_ENABLED] ?: false }
    val isFingerprintEnabled: Flow<Boolean> = context.dataStore.data.map { it[Keys.FINGERPRINT_ENABLED] ?: true }
    val defaultRepeatCount: Flow<Int> = context.dataStore.data.map { it[Keys.DEFAULT_REPEAT_COUNT] ?: 1 }
    val backgroundPlaybackEnabled: Flow<Boolean> = context.dataStore.data.map { it[Keys.BACKGROUND_PLAYBACK] ?: true }

    suspend fun setDarkTheme(value: Boolean) = context.dataStore.edit { it[Keys.DARK_THEME] = value }
    suspend fun setPasswordEnabled(value: Boolean) = context.dataStore.edit { it[Keys.PASSWORD_ENABLED] = value }
    suspend fun setFingerprintEnabled(value: Boolean) = context.dataStore.edit { it[Keys.FINGERPRINT_ENABLED] = value }
    suspend fun setDefaultRepeatCount(value: Int) = context.dataStore.edit { it[Keys.DEFAULT_REPEAT_COUNT] = value }
    suspend fun setBackgroundPlaybackEnabled(value: Boolean) = context.dataStore.edit { it[Keys.BACKGROUND_PLAYBACK] = value }
}
