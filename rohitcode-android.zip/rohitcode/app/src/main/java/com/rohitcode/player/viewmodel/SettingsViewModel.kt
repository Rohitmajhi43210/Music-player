package com.rohitcode.player.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.rohitcode.player.security.AppLockManager
import com.rohitcode.player.settings.SettingsRepository
import kotlinx.coroutines.launch

class SettingsViewModel(
    val settingsRepository: SettingsRepository,
    val appLockManager: AppLockManager
) : ViewModel() {

    fun setDarkTheme(value: Boolean) = viewModelScope.launch { settingsRepository.setDarkTheme(value) }

    fun setFingerprintEnabled(value: Boolean) = viewModelScope.launch { settingsRepository.setFingerprintEnabled(value) }

    fun setBackgroundPlayback(value: Boolean) = viewModelScope.launch { settingsRepository.setBackgroundPlaybackEnabled(value) }

    fun setDefaultRepeatCount(value: Int) = viewModelScope.launch { settingsRepository.setDefaultRepeatCount(value.coerceAtLeast(1)) }

    fun setPassword(raw: String) {
        appLockManager.setPassword(raw)
        viewModelScope.launch { settingsRepository.setPasswordEnabled(true) }
    }

    fun disablePassword() {
        appLockManager.clearPassword()
        viewModelScope.launch { settingsRepository.setPasswordEnabled(false) }
    }
}
