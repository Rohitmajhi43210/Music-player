# Add project specific ProGuard rules here.
# Minification is off by default for this project (see app/build.gradle.kts),
# so this file is a placeholder for when you turn it on later.
